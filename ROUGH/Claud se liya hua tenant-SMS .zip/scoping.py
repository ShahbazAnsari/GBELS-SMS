"""
Tenant scoping + permissions.

Idea: har request par pehle pata karo ke user kis kis school/branch tak pahunch
sakta hai (Scope), phir har queryset ko usi scope se filter karo.
Is liye view likhne wala bhool bhi jaye to data leak nahi hota.
"""
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from rest_framework import permissions, viewsets
from rest_framework.exceptions import PermissionDenied, ValidationError

from .models import Branch, Membership

R = Membership.Role


class Scope:
    """
    Computed once per request from the user's Memberships.

    school_ids        : schools user belongs to in ANY role     (read)
    admin_school_ids  : schools where user is SCHOOL_ADMIN      (school-level write)
    branch_ids        : branches user can see                   (read)
    write_branch_ids  : branches user can modify                (branch-level write)
    """

    def __init__(self, user):
        self.user = user
        self.is_platform = bool(user.is_authenticated and user.is_superuser)
        self.school_ids, self.admin_school_ids = set(), set()
        self.branch_ids, self.write_branch_ids = set(), set()
        if not user.is_authenticated or self.is_platform:
            return

        ms = list(user.memberships.filter(is_active=True, school__is_active=True))
        self.school_ids = {m.school_id for m in ms}
        self.admin_school_ids = {m.school_id for m in ms if m.role == R.SCHOOL_ADMIN}

        # School admin -> all branches of that school
        admin_branches = set(Branch.objects.filter(
            school_id__in=self.admin_school_ids).values_list("id", flat=True))
        own_branches = {m.branch_id for m in ms if m.branch_id}
        branch_admin_branches = {m.branch_id for m in ms
                                 if m.role == R.BRANCH_ADMIN and m.branch_id}

        self.branch_ids = admin_branches | own_branches
        self.write_branch_ids = admin_branches | branch_admin_branches

    def ids(self, kind, write=False):
        """kind: 'school' | 'branch'. Returns None for platform (= no limit)."""
        if self.is_platform:
            return None
        if kind == "school":
            return self.admin_school_ids if write else self.school_ids
        return self.write_branch_ids if write else self.branch_ids


def get_scope(request):
    if not hasattr(request, "_scope"):
        request._scope = Scope(request.user)
    return request._scope


# ----------------------------------------------------------------------
# Permissions
# ----------------------------------------------------------------------
class IsPlatformAdmin(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_superuser)


class ScopedPermission(permissions.BasePermission):
    """
    Read  : koi bhi active member (ya platform admin).
    Write : view.write_kind ke mutabiq
              'school' -> sirf SCHOOL_ADMIN (ya platform)
              'branch' -> SCHOOL_ADMIN ya BRANCH_ADMIN (ya platform)
              'platform' -> sirf platform admin
    Object-level ya record-level check viewset ke scoped queryset se hota hai.
    """

    def has_permission(self, request, view):
        u = request.user
        if not (u and u.is_authenticated):
            return False
        scope = get_scope(request)
        if scope.is_platform:
            return True
        if request.method in permissions.SAFE_METHODS:
            return bool(scope.school_ids)
        kind = getattr(view, "write_kind", "branch")
        if kind == "platform":
            return False
        if kind == "school":
            return bool(scope.admin_school_ids)
        return bool(scope.write_branch_ids)


# ----------------------------------------------------------------------
# Scoped ViewSet
# ----------------------------------------------------------------------
class ScopedModelViewSet(viewsets.ModelViewSet):
    """
    Subclass me sirf ye set karein:
        queryset      = Model.objects.all()
        scope_kind    = "school" | "branch"
        scope_path    = "school_id" | "branch_id" | "section__branch_class__branch_id" ...
        write_kind    = "school" | "branch" | "platform"

    Kya milta hai:
      * list/retrieve sirf scope ke andar ka data dikhata hai
      * create/update ke baad check hota hai ke record user ke write-scope me hai
        (warna rollback + 403), is se doosre school/branch ki ID bhej kar
        chori nahi ho sakti
      * model.clean() chalta hai (cross-school/branch consistency)
    """
    permission_classes = [ScopedPermission]
    scope_kind = "branch"
    scope_path = None
    write_kind = "branch"

    # -- scoping --------------------------------------------------------
    def _path(self):
        return self.scope_path or f"{self.scope_kind}_id"

    def scope_queryset(self, qs, write=False):
        ids = get_scope(self.request).ids(self.scope_kind, write=write)
        if ids is None:
            return qs
        return qs.filter(**{f"{self._path()}__in": ids})

    def get_queryset(self):
        return self.scope_queryset(super().get_queryset())

    # -- guarded writes -------------------------------------------------
    def _guard(self, obj):
        try:
            obj.clean()
        except DjangoValidationError as e:
            raise ValidationError(e.messages)
        allowed = self.scope_queryset(type(obj).objects.all(), write=True)
        if not allowed.filter(pk=obj.pk).exists():
            raise PermissionDenied("Ye record aap ke scope se bahar hai.")

    def perform_create(self, serializer):
        with transaction.atomic():
            obj = serializer.save()
            self._guard(obj)

    def perform_update(self, serializer):
        with transaction.atomic():
            obj = serializer.save()
            self._guard(obj)

    def perform_destroy(self, instance):
        if not self.scope_queryset(type(instance).objects.all(), write=True)\
                .filter(pk=instance.pk).exists():
            raise PermissionDenied("Ye record aap ke scope se bahar hai.")
        instance.delete()
