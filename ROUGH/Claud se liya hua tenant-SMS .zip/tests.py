from rest_framework.test import APITestCase

from .models import User


class FlowTests(APITestCase):
    """Poora flow: super user -> school -> branch -> admission -> lookup, plus isolation."""

    def as_user(self, user):
        self.client.force_authenticate(user)

    def post(self, url, data, code=201):
        r = self.client.post(url, data, format="json")
        self.assertEqual(r.status_code, code, f"{url} -> {r.status_code} {r.content[:300]}")
        return r.json() if r.content else None

    def setUp(self):
        self.root = User.objects.create_superuser("root", password="x" * 10)
        self.as_user(self.root)

        # Step 1: platform admin schools banata hai
        self.post("/api/schools/", {"name": "Alpha School", "code": "ALP",
                                    "admin_username": "alpha_admin", "admin_password": "password123"})
        self.post("/api/schools/", {"name": "Beta School", "code": "BET",
                                    "admin_username": "beta_admin", "admin_password": "password123"})
        self.alpha = User.objects.get(username="alpha_admin")
        self.beta = User.objects.get(username="beta_admin")

        # Step 2: Alpha ka school admin setup karta hai
        self.as_user(self.alpha)
        self.b1 = self.post("/api/branches/", {"name": "Main", "code": "MAIN"})
        self.b2 = self.post("/api/branches/", {"name": "Gulshan", "code": "GUL"})
        self.post("/api/branch-admins/", {"branch": self.b1["id"], "username": "main_admin",
                                          "password": "password123"})
        self.post("/api/branch-admins/", {"branch": self.b2["id"], "username": "gul_admin",
                                          "password": "password123"})
        self.year = self.post("/api/academic-years/", {"name": "2025-26",
                              "start_date": "2025-04-01", "end_date": "2026-03-31", "is_current": True})
        self.med = self.post("/api/mediums/", {"name": "English"})
        self.cl = self.post("/api/class-levels/", {"name": "Class 1", "order": 1})
        self.main_admin = User.objects.get(username="main_admin")
        self.gul_admin = User.objects.get(username="gul_admin")

        # Step 3: Main branch admin apni branch setup karta hai
        self.as_user(self.main_admin)
        self.bc = self.post("/api/branch-classes/", {"academic_year": self.year["id"],
                            "class_level": self.cl["id"], "medium": self.med["id"]})  # branch auto-fill
        self.sec = self.post("/api/sections/", {"branch_class": self.bc["id"], "name": "A"})

    def admit(self, roll=1, name="Ali"):
        return self.post("/api/admissions/admit/", {
            "branch": self.b1["id"], "section": self.sec["id"], "roll_no": roll,
            "admitted_on": "2025-04-05", "first_name": name, "gender": "M",
            "guardian_name": "Ahmed"})

    # ---- happy path ---------------------------------------------------
    def test_admission_generates_three_level_ids(self):
        p1, p2 = self.admit(1, "Ali"), self.admit(2, "Sara")
        self.assertRegex(p1["student_id"], r"^ALP-\d{2}-000001$")
        self.assertEqual(p2["student_id"][-6:], "000002")
        self.assertEqual((p1["gr_no"], p2["gr_no"]), (1, 2))
        self.assertEqual((p1["roll_no"], p1["school"], p1["branch"], p1["class"], p1["section"]),
                         (1, "Alpha School", "Main", "Class 1", "A"))

    def test_lookup_by_student_id(self):
        sid = self.admit()["student_id"]
        r = self.client.get(f"/api/lookup/{sid}/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["branch"], "Main")

    def test_duplicate_roll_no_rejected(self):
        self.admit(1)
        r = self.client.post("/api/admissions/admit/", {
            "branch": self.b1["id"], "section": self.sec["id"], "roll_no": 1,
            "admitted_on": "2025-04-05", "first_name": "X", "gender": "M"}, format="json")
        self.assertEqual(r.status_code, 400)

    def test_gr_no_is_per_branch_and_id_survives_transfer(self):
        sid = self.admit()["student_id"]
        adm = self.client.get("/api/admissions/").json()[0]
        # Main branch admin sirf apni branch me write kar sakta hai -> school admin transfer kare
        self.as_user(self.alpha)
        new = self.post(f"/api/admissions/{adm['id']}/transfer/", {"to_branch": self.b2["id"]})
        self.assertEqual(new["gr_no"], 1)  # Gulshan ka pehla GR No
        self.assertEqual(new["branch"], self.b2["id"])
        # Student ID wohi
        self.assertEqual(self.client.get("/api/students/").json()[0]["student_id"], sid)

    # ---- hierarchy / permissions ---------------------------------------
    def test_only_platform_admin_creates_schools(self):
        self.as_user(self.alpha)
        self.post("/api/schools/", {"name": "Evil", "code": "EVL",
                  "admin_username": "e", "admin_password": "password123"}, code=403)

    def test_branch_admin_cannot_create_branch_or_admin(self):
        self.post("/api/branches/", {"name": "New", "code": "NEW"}, code=403)
        self.post("/api/branch-admins/", {"branch": self.b1["id"], "username": "z",
                                          "password": "password123"}, code=403)

    # ---- isolation ----------------------------------------------------
    def test_other_branch_admin_sees_nothing(self):
        self.admit()
        self.as_user(self.gul_admin)
        self.assertEqual(self.client.get("/api/students/").json(), [])
        self.assertEqual(self.client.get("/api/sections/").json(), [])
        self.assertEqual(self.client.get("/api/admissions/").json(), [])
        self.assertEqual(len(self.client.get("/api/branches/").json()), 1)  # sirf apni
        self.post("/api/sections/", {"branch_class": self.bc["id"], "name": "Z"}, code=403)

    def test_other_branch_admin_cannot_lookup(self):
        sid = self.admit()["student_id"]
        self.as_user(self.gul_admin)
        self.assertEqual(self.client.get(f"/api/lookup/{sid}/").status_code, 404)

    def test_other_school_sees_nothing(self):
        sid = self.admit()["student_id"]
        self.as_user(self.beta)
        self.assertEqual(self.client.get("/api/branches/").json(), [])
        self.assertEqual(self.client.get("/api/students/").json(), [])
        self.assertEqual(self.client.get(f"/api/lookup/{sid}/").status_code, 404)
        self.assertEqual(len(self.client.get("/api/schools/").json()), 1)  # sirf apna

    def test_cannot_write_into_other_school(self):
        self.as_user(self.beta)
        # Alpha ki branch ID ke saath admit karne ki koshish
        r = self.client.post("/api/admissions/admit/", {
            "branch": self.b1["id"], "section": self.sec["id"], "roll_no": 9,
            "admitted_on": "2025-04-05", "first_name": "Hack", "gender": "M"}, format="json")
        self.assertIn(r.status_code, (400, 403))
        self.as_user(self.root)
        self.assertEqual(len(self.client.get("/api/students/").json()), 0)

    def test_me_endpoint(self):
        r = self.client.get("/api/me/").json()
        self.assertEqual(r["memberships"][0]["role"], "BRANCH_ADMIN")
