from django.db import transaction
from rest_framework import serializers

from .models import (AcademicYear, Admission, Branch, BranchClass, ClassLevel,
                     Enrollment, Guardian, Medium, Membership, School, Section,
                     Student, User)
from .scoping import get_scope


# ----------------------------------------------------------------------
# Auto-fill helper: agar user ke paas sirf ek school / branch hai to
# client ko school/branch bhejna zaroori nahi.
# ----------------------------------------------------------------------
class AutoScopeFieldsMixin:
    """
    Create par school/branch missing ho aur user ke paas sirf ek option ho to
    khud bhar deta hai. Ye input parse hone se PEHLE hota hai, kyunke DRF ke
    unique-together validators validate() se pehle chalte hain.
    """

    def get_fields(self):
        fields = super().get_fields()
        for name in ("school", "branch"):
            if name in fields and not fields[name].read_only:
                fields[name].required = False
        return fields

    def to_internal_value(self, data):
        if self.instance is None:
            scope = get_scope(self.context["request"])
            data = data.copy()
            for name, ids in (("school", scope.admin_school_ids),
                              ("branch", scope.write_branch_ids)):
                if name in self.fields and not data.get(name):
                    if len(ids) != 1:
                        raise serializers.ValidationError({name: "Ye field zaroori hai."})
                    data[name] = next(iter(ids))
        return super().to_internal_value(data)


# ----------------------------------------------------------------------
# School / Branch
# ----------------------------------------------------------------------
class SchoolSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = ["id", "name", "code", "registration_number", "logo", "email",
                  "phone", "website", "currency", "timezone", "config", "is_active"]
        read_only_fields = ["code"]  # code Student ID me use hota hai, badalna nahi chahiye


class SchoolCreateSerializer(serializers.ModelSerializer):
    """Platform admin: School + School Admin user ek sath banata hai."""
    admin_username = serializers.CharField(write_only=True)
    admin_password = serializers.CharField(write_only=True, min_length=8)
    admin_email = serializers.EmailField(write_only=True, required=False, default="")

    class Meta:
        model = School
        fields = ["id", "name", "code", "registration_number", "email", "phone",
                  "currency", "timezone", "admin_username", "admin_password", "admin_email"]

    def validate_admin_username(self, v):
        if User.objects.filter(username=v).exists():
            raise serializers.ValidationError("Ye username pehle se maujood hai.")
        return v

    @transaction.atomic
    def create(self, data):
        username = data.pop("admin_username")
        password = data.pop("admin_password")
        email = data.pop("admin_email", "")
        school = School.objects.create(created_by=self.context["request"].user, **data)
        user = User.objects.create_user(username=username, password=password, email=email)
        Membership.objects.create(user=user, school=school, role=Membership.Role.SCHOOL_ADMIN)
        return school


class BranchSerializer(AutoScopeFieldsMixin, serializers.ModelSerializer):
    class Meta:
        model = Branch
        fields = ["id", "school", "name", "code", "address", "city", "district",
                  "province", "phone", "email", "latitude", "longitude", "config", "is_active"]


class BranchAdminSerializer(serializers.ModelSerializer):
    """School admin: branch admin ka user + membership banata hai."""
    username = serializers.CharField(write_only=True)
    password = serializers.CharField(write_only=True, min_length=8)
    email = serializers.EmailField(write_only=True, required=False, default="")
    user_id = serializers.IntegerField(source="user.id", read_only=True)
    user_name = serializers.CharField(source="user.username", read_only=True)

    class Meta:
        model = Membership
        fields = ["id", "branch", "is_active", "username", "password", "email",
                  "user_id", "user_name"]

    def validate_username(self, v):
        if User.objects.filter(username=v).exists():
            raise serializers.ValidationError("Ye username pehle se maujood hai.")
        return v

    def create(self, data):
        user = User.objects.create_user(username=data.pop("username"),
                                        password=data.pop("password"),
                                        email=data.pop("email", ""))
        branch = data["branch"]
        return Membership.objects.create(user=user, school=branch.school,
                                         role=Membership.Role.BRANCH_ADMIN, **data)


# ----------------------------------------------------------------------
# Academics
# ----------------------------------------------------------------------
class AcademicYearSerializer(AutoScopeFieldsMixin, serializers.ModelSerializer):
    class Meta:
        model = AcademicYear
        fields = ["id", "school", "name", "start_date", "end_date", "is_current"]


class MediumSerializer(AutoScopeFieldsMixin, serializers.ModelSerializer):
    class Meta:
        model = Medium
        fields = ["id", "school", "name", "is_active"]


class ClassLevelSerializer(AutoScopeFieldsMixin, serializers.ModelSerializer):
    class Meta:
        model = ClassLevel
        fields = ["id", "school", "name", "order", "next_level"]


class BranchClassSerializer(AutoScopeFieldsMixin, serializers.ModelSerializer):
    class Meta:
        model = BranchClass
        fields = ["id", "branch", "academic_year", "class_level", "medium"]


class SectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Section
        fields = ["id", "branch_class", "name", "capacity", "class_teacher"]


# ----------------------------------------------------------------------
# Students
# ----------------------------------------------------------------------
class StudentSerializer(AutoScopeFieldsMixin, serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ["id", "school", "student_id", "first_name", "last_name", "father_name",
                  "gender", "date_of_birth", "b_form_number", "photo", "status", "extra"]
        read_only_fields = ["student_id"]


class GuardianSerializer(serializers.ModelSerializer):
    class Meta:
        model = Guardian
        fields = ["id", "student", "name", "relation", "phone", "cnic", "is_primary"]

    def create(self, data):
        data["school"] = data["student"].school
        return super().create(data)


class AdmissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Admission
        fields = ["id", "student", "branch", "gr_no", "admitted_on", "left_on", "is_active"]
        read_only_fields = ["gr_no"]


class EnrollmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Enrollment
        fields = ["id", "admission", "academic_year", "section", "roll_no", "is_current"]

    def create(self, data):
        obj = super().create(data)
        if obj.is_current:  # promotion: purani enrollment history ban jati hai
            Enrollment.objects.filter(admission=obj.admission).exclude(pk=obj.pk)\
                .update(is_current=False)
        return obj


# ----------------------------------------------------------------------
# One-shot admission: Student + Admission(GR) + Enrollment(roll no)
# ----------------------------------------------------------------------
class AdmitStudentSerializer(serializers.Serializer):
    branch = serializers.PrimaryKeyRelatedField(queryset=Branch.objects.all())
    section = serializers.PrimaryKeyRelatedField(queryset=Section.objects.all())
    roll_no = serializers.IntegerField(min_value=1)
    admitted_on = serializers.DateField()

    first_name = serializers.CharField()
    last_name = serializers.CharField(required=False, allow_blank=True, default="")
    father_name = serializers.CharField(required=False, allow_blank=True, default="")
    gender = serializers.ChoiceField(choices=["M", "F", "O"])
    date_of_birth = serializers.DateField(required=False, allow_null=True)
    b_form_number = serializers.CharField(required=False, allow_blank=True, default="")

    guardian_name = serializers.CharField(required=False, allow_blank=True, default="")
    guardian_relation = serializers.CharField(required=False, default="Father")
    guardian_phone = serializers.CharField(required=False, allow_blank=True, default="")

    def validate(self, a):
        scope = get_scope(self.context["request"])
        ids = scope.ids("branch", write=True)
        if ids is not None and a["branch"].id not in ids:
            raise serializers.ValidationError({"branch": "Is branch me admission ka haq nahi."})
        if a["section"].branch_class.branch_id != a["branch"].id:
            raise serializers.ValidationError({"section": "Section is branch ka nahi hai."})
        if Enrollment.objects.filter(section=a["section"], roll_no=a["roll_no"]).exists():
            raise serializers.ValidationError({"roll_no": "Is section me ye roll no le liya gaya hai."})
        return a

    @transaction.atomic
    def create(self, a):
        branch, section = a["branch"], a["section"]
        student = Student.objects.create(
            school=branch.school, first_name=a["first_name"], last_name=a["last_name"],
            father_name=a["father_name"], gender=a["gender"],
            date_of_birth=a.get("date_of_birth"), b_form_number=a["b_form_number"])
        if a["guardian_name"]:
            Guardian.objects.create(school=branch.school, student=student,
                                    name=a["guardian_name"], relation=a["guardian_relation"],
                                    phone=a["guardian_phone"], is_primary=True)
        admission = Admission.objects.create(student=student, branch=branch,
                                             admitted_on=a["admitted_on"])
        Enrollment.objects.create(admission=admission,
                                  academic_year=section.branch_class.academic_year,
                                  section=section, roll_no=a["roll_no"])
        return student
