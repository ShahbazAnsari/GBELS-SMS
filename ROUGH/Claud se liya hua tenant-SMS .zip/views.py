from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.exceptions import NotFound, PermissionDenied
from rest_framework.response import Response
from rest_framework.views import APIView

from . import serializers as s
from .models import (AcademicYear, Admission, Branch, BranchClass, ClassLevel,
                     Enrollment, Guardian, Medium, Membership, School, Section,
                     Student, student_profile_by_id)
from .scoping import ScopedModelViewSet, get_scope


# ----------------------------------------------------------------------
# Level 1: Platform  ->  Schools
# ----------------------------------------------------------------------
class SchoolViewSet(ScopedModelViewSet):
    """Create/Delete: sirf platform admin. Update: school admin (apna school)."""
    queryset = School.objects.all()
    scope_kind, scope_path, write_kind = "school", "id", "school"

    def get_serializer_class(self):
        return s.SchoolCreateSerializer if self.action == "create" else s.SchoolSerializer

    def _platform_only(self):
        if not get_scope(self.request).is_platform:
            raise PermissionDenied("Ye kaam sirf platform admin kar sakta hai.")

    def perform_create(self, serializer):
        self._platform_only()
        super().perform_create(serializer)

    def perform_destroy(self, instance):
        self._platform_only()
        super().perform_destroy(instance)


# ----------------------------------------------------------------------
# Level 2: School admin  ->  Branches, branch admins, school-wide lookups
# ----------------------------------------------------------------------
class BranchViewSet(ScopedModelViewSet):
    queryset = Branch.objects.select_related("school")
    serializer_class = s.BranchSerializer
    scope_kind, scope_path, write_kind = "branch", "id", "school"

    def scope_queryset(self, qs, write=False):
        sc = get_scope(self.request)
        if sc.is_platform:
            return qs
        if write:  # branch banana/badalna sirf school admin ka kaam
            return qs.filter(school_id__in=sc.admin_school_ids)
        return qs.filter(id__in=sc.branch_ids)


class BranchAdminViewSet(ScopedModelViewSet):
    queryset = Membership.objects.filter(role=Membership.Role.BRANCH_ADMIN)\
        .select_related("user", "branch")
    serializer_class = s.BranchAdminSerializer
    scope_kind, write_kind = "school", "school"

    def scope_queryset(self, qs, write=False):  # read bhi sirf school admin ko
        sc = get_scope(self.request)
        return qs if sc.is_platform else qs.filter(school_id__in=sc.admin_school_ids)


class AcademicYearViewSet(ScopedModelViewSet):
    queryset = AcademicYear.objects.all()
    serializer_class = s.AcademicYearSerializer
    scope_kind, write_kind = "school", "school"


class MediumViewSet(ScopedModelViewSet):
    queryset = Medium.objects.all()
    serializer_class = s.MediumSerializer
    scope_kind, write_kind = "school", "school"


class ClassLevelViewSet(ScopedModelViewSet):
    queryset = ClassLevel.objects.all()
    serializer_class = s.ClassLevelSerializer
    scope_kind, write_kind = "school", "school"


# ----------------------------------------------------------------------
# Level 3: Branch admin  ->  apni branch ka data
# ----------------------------------------------------------------------
class BranchClassViewSet(ScopedModelViewSet):
    queryset = BranchClass.objects.select_related("class_level", "medium", "academic_year")
    serializer_class = s.BranchClassSerializer
    scope_kind, write_kind = "branch", "branch"


class SectionViewSet(ScopedModelViewSet):
    queryset = Section.objects.all()
    serializer_class = s.SectionSerializer
    scope_kind, scope_path = "branch", "branch_class__branch_id"


class _StudentScopeMixin:
    """
    Student school-level table hai, lekin branch admin sirf unhein dekhe jin ka
    uski branch me admission hai.  student_path: is model se Student tak ka rasta.
    """
    student_path = ""

    def scope_queryset(self, qs, write=False):
        sc = get_scope(self.request)
        if sc.is_platform:
            return qs
        p = self.student_path
        branch_ids = sc.write_branch_ids if write else sc.branch_ids
        return qs.filter(Q(**{f"{p}school_id__in": sc.admin_school_ids}) |
                         Q(**{f"{p}admissions__branch_id__in": branch_ids})).distinct()


class StudentViewSet(_StudentScopeMixin, ScopedModelViewSet):
    queryset = Student.objects.all()
    serializer_class = s.StudentSerializer
    write_kind = "branch"


class GuardianViewSet(_StudentScopeMixin, ScopedModelViewSet):
    queryset = Guardian.objects.all()
    serializer_class = s.GuardianSerializer
    student_path = "student__"
    write_kind = "branch"


class AdmissionViewSet(ScopedModelViewSet):
    queryset = Admission.objects.select_related("student", "branch")
    serializer_class = s.AdmissionSerializer
    scope_kind, write_kind = "branch", "branch"

    @action(detail=False, methods=["post"])
    def admit(self, request):
        """Student + Student ID + GR No + Section + Roll No, sab ek hi call me."""
        ser = s.AdmitStudentSerializer(data=request.data, context={"request": request})
        ser.is_valid(raise_exception=True)
        student = ser.save()
        return Response(student_profile_by_id(student.student_id),
                        status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def transfer(self, request, pk=None):
        """Doosri branch me transfer: purana admission band, naya GR No, wohi Student ID."""
        old = self.get_object()
        to_branch = Branch.objects.filter(pk=request.data.get("to_branch")).first()
        write_ids = get_scope(request).ids("branch", write=True)
        if not to_branch or (write_ids is not None and to_branch.id not in write_ids):
            raise PermissionDenied("Destination branch par aap ka haq nahi.")
        if to_branch.school_id != old.branch.school_id:
            raise PermissionDenied("Transfer sirf usi school ki branches me ho sakta hai.")
        with transaction.atomic():
            old.is_active, old.left_on = False, timezone.localdate()
            old.save(update_fields=["is_active", "left_on", "updated_at"])
            Enrollment.objects.filter(admission=old).update(is_current=False)
            new = Admission.objects.create(student=old.student, branch=to_branch,
                                           admitted_on=timezone.localdate())
        return Response(s.AdmissionSerializer(new).data, status=status.HTTP_201_CREATED)


class EnrollmentViewSet(ScopedModelViewSet):
    queryset = Enrollment.objects.select_related("admission", "section")
    serializer_class = s.EnrollmentSerializer
    scope_kind, write_kind = "branch", "branch"
    scope_path = "admission__branch_id"


# ----------------------------------------------------------------------
# Utility endpoints
# ----------------------------------------------------------------------
class MeView(APIView):
    def get(self, request):
        u = request.user
        return Response({
            "username": u.username,
            "is_platform_admin": u.is_superuser,
            "memberships": [
                {"role": m.role, "school": m.school.name, "school_id": m.school_id,
                 "branch": m.branch.name if m.branch else None, "branch_id": m.branch_id}
                for m in u.memberships.filter(is_active=True).select_related("school", "branch")
            ],
        })


class StudentLookupView(APIView):
    """ID se puri info: school, branch, GR No, class, section, roll no."""

    def get(self, request, student_id):
        sc = get_scope(request)
        profile = student_profile_by_id(student_id, branch_ids=sc.ids("branch"))
        if not profile:
            raise NotFound("Is ID ka student nahi mila (ya aap ke scope me nahi).")
        return Response(profile)
